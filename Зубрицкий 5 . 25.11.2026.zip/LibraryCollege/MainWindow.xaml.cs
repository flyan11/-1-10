using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace LibraryCollege;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<Book> books = new();

    public ICommand DeleteCommand { get; }

    public MainWindow()
    {
        InitializeComponent();

        DeleteCommand = new RelayCommand(
            execute: DeleteSelectedBook,
            canExecute: () => BooksGrid.SelectedItem is Book);

        DataContext = this;

        books.Add(new Book { Id = 1, Title = "Война и мир", Author = "Л. Толстой", Year = 1869, ISBN = "978-5-17-090123-4", Quantity = 5 });
        books.Add(new Book { Id = 2, Title = "Преступление и наказание", Author = "Ф. Достоевский", Year = 1866, ISBN = "978-5-17-090124-1", Quantity = 3 });
        books.Add(new Book { Id = 3, Title = "Евгений Онегин", Author = "А. Пушкин", Year = 1833, ISBN = "978-5-17-090125-8", Quantity = 7 });

        BooksGrid.ItemsSource = books;
    }

    private void Exit_Click(object sender, RoutedEventArgs e)
    {
        Application.Current.Shutdown();
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        var window = new BookEditorWindow { Owner = this };
        if (window.ShowDialog() == true)
        {
            window.EditedBook.Id = books.Count == 0 ? 1 : books.Max(book => book.Id) + 1;
            books.Add(window.EditedBook);
        }
    }

    private void Edit_Click(object sender, RoutedEventArgs e)
    {
        if (BooksGrid.SelectedItem is not Book book)
        {
            MessageBox.Show("Выберите книгу.");
            return;
        }

        var window = new BookEditorWindow(book) { Owner = this };
        if (window.ShowDialog() == true)
        {
            book.Title = window.EditedBook.Title;
            book.Author = window.EditedBook.Author;
            book.Year = window.EditedBook.Year;
            book.ISBN = window.EditedBook.ISBN;
            book.Quantity = window.EditedBook.Quantity;
            BooksGrid.Items.Refresh();
        }
    }

    private void DeleteSelectedBook()
    {
        if (BooksGrid.SelectedItem is not Book book)
            return;

        if (MessageBox.Show($"Удалить книгу «{book.Title}»?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
        {
            books.Remove(book);
        }
    }

    private void BooksGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        CommandManager.InvalidateRequerySuggested();
    }

    private void Search_Click(object sender, RoutedEventArgs e)
    {
        string query = SearchBox.Text.Trim();
        BooksGrid.ItemsSource = string.IsNullOrEmpty(query)
            ? books
            : books.Where(book => book.Title.Contains(query, StringComparison.CurrentCultureIgnoreCase)).ToList();
        CommandManager.InvalidateRequerySuggested();
    }

    private void Reset_Click(object sender, RoutedEventArgs e)
    {
        SearchBox.Clear();
        BooksGrid.ItemsSource = books;
        CommandManager.InvalidateRequerySuggested();
    }
}
