using System.Windows;
using System.Windows.Input;

namespace LibraryCollege;

public partial class BookEditorWindow : Window
{
    public Book EditedBook { get; private set; } = new();

    public ICommand SaveCommand { get; }

    public BookEditorWindow()
    {
        InitializeComponent();

        SaveCommand = new RelayCommand(
            execute: SaveBook,
            canExecute: () => !string.IsNullOrWhiteSpace(TitleBox.Text));

        DataContext = this;
    }

    public BookEditorWindow(Book book) : this()
    {
        Title = "Редактирование книги";
        TitleBox.Text = book.Title;
        AuthorBox.Text = book.Author;
        YearBox.Text = book.Year.ToString();
        IsbnBox.Text = book.ISBN;
        QuantityBox.Text = book.Quantity.ToString();
    }

    private void TitleBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        CommandManager.InvalidateRequerySuggested();
    }

    private void SaveBook()
    {
        if (string.IsNullOrWhiteSpace(TitleBox.Text) ||
            string.IsNullOrWhiteSpace(AuthorBox.Text) ||
            !int.TryParse(YearBox.Text, out int year) ||
            !int.TryParse(QuantityBox.Text, out int quantity) || quantity < 0)
        {
            MessageBox.Show(
                "Заполните название, автора, корректный год и количество.",
                "Проверка данных",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        EditedBook = new Book
        {
            Title = TitleBox.Text.Trim(),
            Author = AuthorBox.Text.Trim(),
            Year = year,
            ISBN = IsbnBox.Text.Trim(),
            Quantity = quantity
        };

        MessageBox.Show(
            $"Сохраняем книгу:\nНазвание: {EditedBook.Title}\nАвтор: {EditedBook.Author}\nГод: {EditedBook.Year}",
            "Сохранение",
            MessageBoxButton.OK,
            MessageBoxImage.Information);

        DialogResult = true;
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
    }
}
