using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace LibraryCollege;

public partial class BookCardControl : UserControl
{
    public BookCardControl()
    {
        InitializeComponent();
        UpdateStatus(IsBorrowed);
    }

    public static readonly DependencyProperty BookTitleProperty =
        DependencyProperty.Register(
            nameof(BookTitle),
            typeof(string),
            typeof(BookCardControl),
            new PropertyMetadata("Без названия", OnBookTitleChanged));

    public string BookTitle
    {
        get => (string)GetValue(BookTitleProperty);
        set => SetValue(BookTitleProperty, value);
    }

    private static void OnBookTitleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var control = (BookCardControl)d;
        control.TxtTitle.Text = e.NewValue as string ?? "Без названия";
    }

    public static readonly DependencyProperty AuthorProperty =
        DependencyProperty.Register(
            nameof(Author),
            typeof(string),
            typeof(BookCardControl),
            new PropertyMetadata("Автор", OnAuthorChanged));

    public string Author
    {
        get => (string)GetValue(AuthorProperty);
        set => SetValue(AuthorProperty, value);
    }

    private static void OnAuthorChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var control = (BookCardControl)d;
        control.TxtAuthor.Text = e.NewValue as string ?? "Автор";
    }

    public static readonly DependencyProperty IsBorrowedProperty =
        DependencyProperty.Register(
            nameof(IsBorrowed),
            typeof(bool),
            typeof(BookCardControl),
            new PropertyMetadata(false, OnIsBorrowedChanged));

    public bool IsBorrowed
    {
        get => (bool)GetValue(IsBorrowedProperty);
        set => SetValue(IsBorrowedProperty, value);
    }

    private static void OnIsBorrowedChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var control = (BookCardControl)d;
        control.UpdateStatus((bool)e.NewValue);
    }

    private void UpdateStatus(bool isBorrowed)
    {
        if (StatusBorder == null || TxtStatus == null)
            return;

        StatusBorder.Background = isBorrowed
            ? new SolidColorBrush(Color.FromRgb(231, 76, 60))
            : new SolidColorBrush(Color.FromRgb(39, 174, 96));
        TxtStatus.Text = isBorrowed ? "Выдана" : "Доступна";
    }
}
