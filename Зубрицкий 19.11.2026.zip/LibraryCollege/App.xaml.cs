using System.Windows;

namespace LibraryCollege;

public partial class App : Application
{
}
