using System.Windows;

namespace LibraryCollege;

public partial class LoginWindow : Window
{
    public LoginWindow()
    {
        InitializeComponent();
    }

    private void EnterButton_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(LoginTextBox.Text) ||
            string.IsNullOrWhiteSpace(PasswordInput.Password))
        {
            MessageBox.Show("Введите логин и пароль.",
                            "Авторизация",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);
            return;
        }

        MessageBox.Show($"Добро пожаловать, {LoginTextBox.Text}!",
                        "Вход выполнен",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
        Close();
    }
}
